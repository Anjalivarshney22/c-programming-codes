/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int power(int,int);

int main()
{
    int n,p;
    scanf("%d",&n);
    scanf("%d",&p);
    int c=power(n,p);
   printf("%d",c);

    return 0;
}
int power(int n,int p){
   int result=1;
   while(p!=0){
       result=result*n;
       --p;
   }
   return(result);
    
}