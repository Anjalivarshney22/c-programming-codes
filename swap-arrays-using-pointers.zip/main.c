/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
// swap two arrays;
void swap(int*p,int*q,int n){
	for(int i=0;i<n;i++)
	{
    int temp;
    temp=*p;
    *p=*q;
    *q=temp;
    p++;
    q++;
}
}
int main()
{
  int n,i;
  scanf("%d",&n);
  int a[n],b[n];
  for(int i=0;i<n;i++){
      scanf("%d",&a[i]);
  }
  for(int i=0;i<n;i++){
      scanf("%d",&b[i]);
  }
  printf("the array after swapping are-");
  swap(a,b,n);
  for(int i=0;i<n;i++){
      printf("%d ",a[i]);
  }
  printf("\n");
  for(int i=0;i<n;i++){
      printf("%d ",b[i]);
  }
  
  
  

    return 0;
}