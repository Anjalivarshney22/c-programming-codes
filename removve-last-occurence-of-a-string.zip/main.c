/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>
int main()
{  int n,index;
   char str[500];
   printf("enter the string:-");
   gets(str);
   int s=strlen(str);
    int i=0;
   printf("enter the  character to remove:-");
   char ch;
   scanf("%c",&ch);
   for(int i=s;i>0;i--){
   	if(str[i]==ch){
   		index=i;
	   }
}
if(index!=-1){
	i=index;
	while(i<s){
		str[i]=str[i+1];
		i++;
	}
}
	   
   
		puts(str);
return 0;
}
