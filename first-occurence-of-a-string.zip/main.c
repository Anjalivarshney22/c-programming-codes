/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>
int main()
{   int f=0,i;
   char str[1000],ch;
   fgets(str,1000,stdin);
   printf("enter the character to search");
   scanf("%c",&ch);
   int s=strlen(str);
   
   for(i=0;i<=s;i++){
   	if(str[i]==ch){
   		f++;
        printf("%d",i);
        break;
	   }
   }
   if(f==0){
   	printf("not found");
   }
    return 0;
}
