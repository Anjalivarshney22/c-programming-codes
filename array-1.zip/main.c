/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{  
    int n;
   int a[n];
   printf("enter the value");
   scanf("%d",&n);
   for (int i=0;i<n;i++){
       printf( "enter the value %d",i);
       scanf("%d",&a[i]);
   }
   printf("\n");
   for (int i=0;i<n;i++){
        printf("the value of %d of the array is %d",i,a[i]);
        printf("\n");
   }

    return 0;
}

