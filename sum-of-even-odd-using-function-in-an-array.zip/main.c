/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int even(int,int),c,d,i,sum1=0,sum2=0;
int main(){
    int start,end;
    scanf("%d %d",&start,&end);
    even(start,end);
}
int even(int a,int b){
    for(int i=a;i<b;i++){
        if(i%2==0){
            sum1+=i;
             printf("\n");
        }
        if(i%2!=0){
         sum2+=i;
        }
    }
    printf("the sum of even are:-%d",sum1);
    printf("\n");
    printf("the sum of odd are:-%d",sum2);
     
}