/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int L(int ,int);
int main()
{ 
    int a,b;
    scanf("%d %d",&a,&b);
    L(a,b);
    printf("%d",L(a,b));
    return 0;
}
int L(int p,int q){
    int LCM;
    int max;
    if(p>q){
        max=p;
    }
    else{
        max=q;
    }
    for(int i=max;;i++){
        if(i%p==0 && i%q==0){
            LCM=i;
            break;
        }
    }
    return(LCM);
}
