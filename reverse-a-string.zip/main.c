/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>
int main()
{   int n;
   char str[n],temp;
   fgets(str,n,stdin);
   int s=strlen(str);
   for(int i=0;i<s/2;i++){
       temp=str[i];
       str[i]=str[s-i-1];
       str[s-i-1]=temp;
       
   }
   puts(str);

    return 0;
}

