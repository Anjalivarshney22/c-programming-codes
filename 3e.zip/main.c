/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   for(int i=1;i<=5;i++){
        for(int j=1;j<i;j++){
           printf(" ");
           
        }
        for(int k=1;k<=5;k++){
           
            printf("*");
        }
        printf("\n");
   }
    return 0;
}

