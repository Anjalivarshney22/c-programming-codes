/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
void darray(int,int,int(*p)[]);
    

int main(){
    int n,m;
    
    scanf("%d",&n);
    scanf("%d",&m);
    
    int a[n][m];
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            scanf("%d",&a[i][j]);
        }}
        darray(n,m,a);
        return 0;
    }
        
void darray(int n,int m,int(*p)[m]){
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            printf("%d",p[i][j]);
    
}
        printf("\n");
    }
    
}

