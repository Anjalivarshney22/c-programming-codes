/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void min_max(int*a,int n){
    int max=a[0];
    int min=a[0];
    int maxpos=0,minpos=0;
    for(int i=0;i<n;i++){
        if(a[i]>max){
            max=a[i];
            maxpos=i;
        }
        if(a[i]<min){
            min=a[i];
            minpos=i;
        }
    }
    int temp=a[maxpos];
    a[maxpos]=a[minpos];
    a[minpos]=temp;
}

int main()
{
   int n;
   scanf("%d",&n);
   int a[n];
   for(int i=0;i<n;i++){
       scanf("%d",&a[i]);
   }
   min_max(a,n);
    for(int i=0;i<n;i++){
       printf("%d ",a[i]);
    }
   
    return 0;
}
