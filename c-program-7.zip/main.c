/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float a;
    printf("enter to convert to fahrenheit:\n",a);
    scanf("%f",&a);
    float b=(a*9/5)+32;
    printf("the value in celsius is%f\n",b);
   
    

    return 0;
}

