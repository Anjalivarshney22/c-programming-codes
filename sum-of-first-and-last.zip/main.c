/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{

 int n, sum=0, firstDigit, lastDigit,temp;
 int k=n;
 scanf("%d", &n);
    lastDigit = n % 10;
    while(n >= 10)
    {
        n = n / 10;
    }
    
    firstDigit = n;
    temp=firstDigit;
    firstDigit=lastDigit;
    lastDigit=temp;
    printf("%d",);
    
    
    return 0;
}
