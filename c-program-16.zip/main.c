/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   float a,b,c,d,e;
   printf("enter the marks:",a);
   scanf("%f",&a);
   printf("enter the marks:",b);
   scanf("%f",&b);
   printf("enter the marks:",c);
   scanf("%f",&c);
   printf("enter the marks:",d);
   scanf("%f",&d);
   printf("enter the marks:",e);
   scanf("%f",&e);
   float total=a+b+c+d+e;
   float average =(a+b+c+d+e)/5;
   float percentage=(total/500)*100;
   printf("the total marks are:%f\n",total);
   printf("thre average marks are:%f\n",average);
   printf("the percentage is:%f\n",percentage);
   
    return 0;
}

