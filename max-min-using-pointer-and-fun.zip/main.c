/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void min_max(int*a,int n,int*min,int*max){
     *max=a[0];
     *min=a[0];
    for(int i=0;i<n;i++){
        if(a[i]>*max){
            *max=a[i];
            
        }
        if(a[i]<*min){
            *min=a[i];
          
        }
    }
    
}

int main()
{
   int n,max=0,min=0;
   scanf("%d",&n);
   int a[n];
   for(int i=0;i<n;i++){
       scanf("%d",&a[i]);
   }
   min_max(a,n,&min,&max);
    for(int i=0;i<n;i++){
       printf(" the max and min value in an array is %d %d ",max,min);
    }
   
    return 0;
}
