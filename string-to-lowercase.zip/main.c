/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>
int main()
{ int n,i,f=0;
    char str[n];

    fgets(str,n,stdin);
    for(int i=0;str[i]!='\0';i++){
       if(str[i]>='A' && str[i]<='Z'){
           str[i]=str[i]+32;
       }
    }
    puts(str);

    return 0;
}
