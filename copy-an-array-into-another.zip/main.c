/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

float area_of_circle(float r)
{
    return(3.14*r*r);
}
int main()
{
  float k;
  float r;
  printf("enter r");
  scanf("%f",&r);
  k=area_of_circle(r);
  printf("%f",k);

    return 0;
}
