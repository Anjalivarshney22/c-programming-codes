/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>
int main()
{
    char str[500];
    int c[26]={0};
    printf("Enter a string:-");
    scanf("%[^\n]s",str);
    for(int i=0;str[i];i++){
        c[str[i]-97]++;
    }
    for(int i=0;i<26;i++){
        if(c[i]>0){
            printf("the occurence of each chafracter %c in a string is %d\n",i+97,c[i]);
        }
    }

    return 0;
}


