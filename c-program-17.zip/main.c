/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float p,t,r;
    printf("enter the principal");
    scanf("%f",&p);
    printf("enter the time:");
    scanf("%f",&t);
    printf("enter the rate:");
    scanf("%f",&r);
    float interest=(p*t*r/100);
    printf("the interest is:%f",interest);
    return 0;
}
