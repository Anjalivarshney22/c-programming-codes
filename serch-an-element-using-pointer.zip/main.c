/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int i,f=0;
// search an element..
void search(int n,int*p,int ele){
    int f=0;
    for (int i=0;i<n;i++)
    {
       if(ele==p[i])
       {
           f=1;
           break;
       }
    }
    if(f==1)
    {
       printf("elememnt found");
   }
   else
   {
       printf("not found");
       
   }
}
int main()
{
   int n,i;
   scanf("%d",&n);
   int a[n];
   for (i=0;i<n;i++)
   {
       scanf("%d",&a[i]);
   }
   int ele;
   scanf("%d",&ele);
   search(n,a,ele);
   
    return 0;
}
