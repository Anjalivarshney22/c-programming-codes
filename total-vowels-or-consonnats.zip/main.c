/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
     int n,i,count1=0,count2=0;
    char str[n];

    fgets(str,n,stdin);
    for(int i=0;str[i]!='\0';i++){
       if(str[i]=='a' || str[i]=='e' ||str[i]=='i' || str[i]=='o'|| str[i]=='u'
       || str[i]=='A' || str[i]=='E' ||str[i]=='I' || str[i]=='O'|| str[i]=='U' ){
           count1++;
       }
       else {
           count2++;
       }
    }
    printf("the total voowels are:--");
    printf("%d\n",count1);
    printf("the total consonants are:-");
    printf("%d",count2);

    return 0;
}
