/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
 #include <stdio.h>
int reverse(int);
int main(){
    int n;
    scanf("%d",&n);
    reverse(n);
    if(reverse(n)==1)
    printf("palindrome");
    else{
        printf("Not a Palindrome");
    }
}
int reverse(int p){
    int rev=0;
    while(p!=0){
    int rem=p%10;
    rev=(10*rev)+rem;
    p=p/10;
    }
    return (1);
}

