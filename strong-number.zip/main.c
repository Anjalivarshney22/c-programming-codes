/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
     int n,fact=1,a=1,sum=0,num;
    scanf("%d",&n);
    int k=n;
    while(k>0){
      num=k%10;
        a=1;fact=1;
    while(a<=num){
        fact=fact*a;
        a=1;
        a++;
    }
    sum=sum+fact;
    k=k/10;
        }
    if(sum==n){
        printf("it is an strong");  
    }
    else{
        printf("not");
        
    }
    
    return 0;
}

