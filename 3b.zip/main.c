/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   for(int i=1;i<=5;i++){
        for(int j=1;j<=5;j++){
            if (j==3&&(i==2||i==4) ||i==3&&(j==2||j==4)){
                printf(" ");
                
            }
            else{
                printf("*");
            }
        
        }
        printf("\n");
        
        }

    return 0;
}

