/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int perfect(int);

int main()
{  
    int n;
   scanf("%d",&n);
   perfect(n);
    if(perfect(n)==1){
        printf("it is perfect");
    }
    else{
        printf("no");
    }
   

    return 0;
}
int perfect(int p){
    int sum=0;
    for(int i=1;i<p;i++){
        int k;
        if(k%i==0){
            sum+=i;
        }
        return 1;
    }
}
