/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
 int n,i,count1=0,count2=0;
    char str[n];

    fgets(str,n,stdin);
    for(int i=0;str[i]!='\0';i++){
       if(str[i]>='a' && str[i]<='z' ||str[i]>='A' && str[i]<='Z' ){
           count1++;
       }
       else if(str[i]>=48 && str[i]<=57){
           count2++;
       }
    }
    printf("the total alphabets are:--");
    printf("%d\n",count1);
    printf("the total digits are:-");
    printf("%d",count2);
    return 0;
}
