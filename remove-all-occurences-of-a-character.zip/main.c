/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>
int main()
{  int n,index;
   char str[500];
   printf("enter the string:-");
   gets(str);
   int s=strlen(str);
    int i=0,j;
   printf("enter the  character to remove:-");
   char ch;
   scanf("%c",&ch);
   
	for(i = 0; i < s; i++)
	{
		if(str[i] == ch)
		{
			for(j = i; j < s; j++)
			{
				str[j] = str[j + 1];
			}
			s--;
			i--;	
		} 
	}		   
   
		puts(str);
return 0;
}