/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    
    int a,b,max,LCM;
    scanf("%d %d",&a,&b);
    if(a>b){
        max=a;
    }
    else{
        max=b;
    }
    for (int i=max;;i++){
        if((i%a==0) && (i%b==0)){
            LCM=i;
            break;}
        }
        printf("%d",LCM);

    return 0;
}

