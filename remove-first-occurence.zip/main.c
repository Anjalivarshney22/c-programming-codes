/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>
int main()
{  int n;
   char str[500];
   printf("enter the string:-");
   gets(str);
   int s=strlen(str);
    int i=0;
   printf("enter the  character to remove:-");
   char ch;
   scanf("%c",&ch);
  
  while(i<s && str[i]!=ch)
{
	i++;
	}
	while(i<s){
		str[i]=str[i+1];
		i++;
	}
	
		puts(str);
return 0;
}

