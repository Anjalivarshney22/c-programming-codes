/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void swap(int *,int*);
int main()
{
    int a,b;
    scanf("%d %d",&a,&b);
    printf("the numbers before swapping are %d %d\n",a,b);
    swap(&a,&b);
    printf("the number after swaping are %d %d",a,b);
}
void swap(int *p,int*q){
    int temp;
    temp=*p;
    *p=*q;
    *q=temp;
}

