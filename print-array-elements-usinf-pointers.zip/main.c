/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void array(int *p,int n){
    for (int i=0;i<n;i++){
        scanf("%d",&p[i]);
    }
}
int main()
{
    int n,a[n];
    scanf("%d",&n);
    array(a,n);
    for(int i=0;i<n;i++){
    printf("%d",a[i]);
}
    return 0;
}
