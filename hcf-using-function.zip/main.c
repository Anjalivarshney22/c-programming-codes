/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int GCD(int ,int),HCF;
int main()
{ 
    int a,b;
    scanf("%d %d",&a,&b);
    GCD(a,b);
    printf("%d",GCD(a,b));
    return 0;
}
int GCD(int p,int q){
    
    int min=0;
    if(p<q){
        min=p;
    }
    else{
        min=q;
    }
    for(int i=min;i>=1;i--){
        if(p%i==0 && q%i==0){
            HCF=i;
            break;
            
        }
    }
    return(HCF);
}