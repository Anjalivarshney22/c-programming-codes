/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,sum=0,rem;
    scanf("%d",&n);
    for(int i=1;i<n;i++){
        rem=n%i;
        if(rem==0){
            sum=sum+i;
        }
        
    }
    if (sum==n)  {
                      printf(" is a Perfect Number");  }
           else  {
                      printf("is not a Perfect Number");  
}
    return 0;
}
