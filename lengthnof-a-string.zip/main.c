/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{   int n,i,length=0,temp=0;
    char str[n];
    fgets(str,n,stdin);
    for(i=0;str[i]!='\0';i++){
          length++;
    }
    printf("the length of the string is");
    printf("%d",length);
    
    
    }
   
    return 0;
}
